
var b0 =document.getElementById('0');
var b1 =document.getElementById('1');
var b2 =document.getElementById('2');
var b3 =document.getElementById('3');
var b4 =document.getElementById('4');
var b5 =document.getElementById('5');
var b6 =document.getElementById('6');
var b7 =document.getElementById('7');
var b8 =document.getElementById('8');
var b9 =document.getElementById('9');
var on=document.getElementById('on');
var punto =document.getElementById('punto');
var signo = document.getElementById('sign');
var mas = document.getElementById('mas');
var menos = document.getElementById('menos');
var por = document.getElementById('por');
var dividido= document.getElementById('dividido');
var iguR = document.getElementById('igual');
var raizc = document.getElementById('raiz');
var numero1=0;
var numero2=0;
var igual=0;
var operacion=""; /*suma , resta, multiplicacion,divicion*/
var tecla=""; /*1,2,3,4,5,6,7,8,9,0*/
var cadena = "0"; /*123 ,564.56*/
var n =0;  /*contador de numeros*/
var puntb='0'; /* determina si la cadena ya tiene punto*/

/*funcion que guarda el primer numero */

function guardaNumero1() {
  numero1= parseFloat(cadena);
  cadena="";
  n=0;
  puntb='0';
  document.getElementById('display').innerHTML=cadena;
}
/*funcion que asigna el numero e imagen */

function agregarNumero() {
  if ((n)<8) {
      if (cadena=='0') {cadena=""}
      cadena= cadena + tecla ;
      document.getElementById('display').innerHTML=cadena;
      numero2= parseFloat(cadena);
      n=n+1;
    }else{
      console.log("ya tiene "+ n + " numeros")
    }
}
/*click en la imagen del numero*/
  b0.addEventListener('click', function(){
  if ((n)<8 && (cadena)!='0') {
    cadena= cadena + "0" ;
    document.getElementById('display').innerHTML=cadena;
    numero2= parseFloat(cadena);
    n=n+1;
  }else{
    console.log("ya tiene "+ n + " numeros")
  }
})
/*click en la imagen del numero*/
  b1.addEventListener('click', function(){
    tecla="1";
    agregarNumero();
})
/*click en la imagen del numero*/
  b2.addEventListener('click', function(){
    tecla="2";
    agregarNumero();
})
/*click en la imagen del numero*/
  b3.addEventListener('click', function(){
    tecla="3";
    agregarNumero();
})
/*click en la imagen del numero*/
  b4.addEventListener('click', function(){
    tecla="4";
    agregarNumero();
})
/*click en la imagen del numero*/
  b5.addEventListener('click', function(){
    tecla="5";
    agregarNumero();
})
/*click en la imagen del numero*/
  b6.addEventListener('click', function(){
    tecla="6";
    agregarNumero();
})
/*click en la imagen del numero*/
  b7.addEventListener('click', function(){
    tecla="7";
    agregarNumero();
})
/*click en la imagen del numero*/
  b8.addEventListener('click', function(){
    tecla="8";
    agregarNumero();
})
/*click en la imagen del numero*/
  b9.addEventListener('click', function(){
    tecla="9";
    agregarNumero();
})


/* tecla on borrar numero*/
on.addEventListener('click', function(){
  cadena="0";
  document.getElementById('display').innerHTML=cadena;
  numero1=0;
  numero2=0;
  n=0;
  puntb='0';
})

punto.addEventListener('click', function(){
  if (cadena=='0') {cadena="0"}
  if (puntb=='0') {
    puntb='1';
    cadena= cadena + "." ;
    document.getElementById('display').innerHTML=cadena;
  }
})

signo.addEventListener('click', function(){
  cadena= parseInt(cadena) *-1 ;
  document.getElementById('display').innerHTML=cadena;
})


/*----operaciones------*/
mas.addEventListener('click', function(){
  guardaNumero1();
  operacion="sumar";
})
menos.addEventListener('click', function(){
  guardaNumero1();
  operacion="restar";
})
por.addEventListener('click', function(){
  guardaNumero1();
  operacion="multiplicar";
})
  dividido.addEventListener('click', function(){
  guardaNumero1();
  operacion="dividir"
})

raizc.addEventListener('click', function(){
  numero1= parseFloat(cadena);
  puntb='1';
  cadena= Math.sqrt(numero1)
  cadena=String(cadena);
  if ((cadena.length)<9) {
    document.getElementById('display').innerHTML=cadena;
  } else {
    cadena=Number(cadena);
    document.getElementById('display').innerHTML=cadena.toPrecision(7);
  }
      n=8;
      numero1=Number(cadena);

})

/*boton calcular operacion*/

iguR.addEventListener('click', function(){
  if ((numero1)!=0) {

    switch (operacion) {
      case 'sumar':
        cadena=numero1+numero2;
        break;
      case 'restar':
        cadena=numero1-numero2;
        break;
      case 'multiplicar':
        cadena=numero1*numero2;
        break;
      default:
      cadena=numero1/numero2;
        break;
    }
    cadena=String(cadena);
    if ((cadena.length)<9) {
      document.getElementById('display').innerHTML=cadena;
    } else {
      cadena=Number(cadena);
      document.getElementById('display').innerHTML=cadena.toPrecision(7);
    }
        n=8;
        numero1=Number(cadena);
        puntb='1';
    }
  })

/*----------efecto de botones------------*/

b0.addEventListener("mousedown", function(){
b0.setAttribute("style","transform:scale(0.95,0.95)")
})
b0.addEventListener("mouseout", function(){
b0.setAttribute("style","transform:scale(1,1)")
})

b1.addEventListener("mousedown", function(){
b1.setAttribute("style","transform:scale(0.95,0.95)")
})
b1.addEventListener("mouseout", function(){
b1.setAttribute("style","transform:scale(1,1)")
})
b2.addEventListener("mousedown", function(){
b2.setAttribute("style","transform:scale(0.95,0.95)")
})
b2.addEventListener("mouseout", function(){
b2.setAttribute("style","transform:scale(1,1)")
})

b3.addEventListener("mousedown", function(){
b3.setAttribute("style","transform:scale(0.95,0.95)")
})
b3.addEventListener("mouseout", function(){
b3.setAttribute("style","transform:scale(1,1)")
})
b4.addEventListener("mousedown", function(){
b4.setAttribute("style","transform:scale(0.95,0.95)")
})
b4.addEventListener("mouseout", function(){
b4.setAttribute("style","transform:scale(1,1)")
})

b5.addEventListener("mousedown", function(){
b5.setAttribute("style","transform:scale(0.95,0.95)")
})
b5.addEventListener("mouseout", function(){
b5.setAttribute("style","transform:scale(1,1)")
})
b6.addEventListener("mousedown", function(){
b6.setAttribute("style","transform:scale(0.95,0.95)")
})
b6.addEventListener("mouseout", function(){
b6.setAttribute("style","transform:scale(1,1)")
})

b7.addEventListener("mousedown", function(){
b7.setAttribute("style","transform:scale(0.95,0.95)")
})
b7.addEventListener("mouseout", function(){
b7.setAttribute("style","transform:scale(1,1)")
})
b8.addEventListener("mousedown", function(){
b8.setAttribute("style","transform:scale(0.95,0.95)")
})
b8.addEventListener("mouseout", function(){
b8.setAttribute("style","transform:scale(1,1)")
})

b9.addEventListener("mousedown", function(){
b9.setAttribute("style","transform:scale(0.95,0.95)")
})
b9.addEventListener("mouseout", function(){
b9.setAttribute("style","transform:scale(1,1)")
})
on.addEventListener("mousedown", function(){
on.setAttribute("style","transform:scale(0.95,0.95)")
})
on.addEventListener("mouseout", function(){
on.setAttribute("style","transform:scale(1,1)")
})

punto.addEventListener("mousedown", function(){
punto.setAttribute("style","transform:scale(0.95,0.95)")
})
punto.addEventListener("mouseout", function(){
punto.setAttribute("style","transform:scale(1,1)")
})
signo.addEventListener("mousedown", function(){
signo.setAttribute("style","transform:scale(0.95,0.95)")
})
signo.addEventListener("mouseout", function(){
signo.setAttribute("style","transform:scale(1,1)")
})

mas.addEventListener("mousedown", function(){
mas.setAttribute("style","transform:scale(0.95,0.95)")
})
mas.addEventListener("mouseout", function(){
mas.setAttribute("style","transform:scale(1,1)")
})

menos.addEventListener("mousedown", function(){
menos.setAttribute("style","transform:scale(0.95,0.95)")
})
menos.addEventListener("mouseout", function(){
menos.setAttribute("style","transform:scale(1,1)")
})

por.addEventListener("mousedown", function(){
por.setAttribute("style","transform:scale(0.95,0.95)")
})
por.addEventListener("mouseout", function(){
por.setAttribute("style","transform:scale(1,1)")
})

dividido.addEventListener("mousedown", function(){
dividido.setAttribute("style","transform:scale(0.95,0.95)")
})
dividido.addEventListener("mouseout", function(){
dividido.setAttribute("style","transform:scale(1,1)")
})

iguR.addEventListener("mousedown", function(){
iguR.setAttribute("style","transform:scale(0.95,0.95)")
})
iguR.addEventListener("mouseout", function(){
iguR.setAttribute("style","transform:scale(1,1)")
})

raiz.addEventListener("mousedown", function(){
raiz.setAttribute("style","transform:scale(0.95,0.95)")
})
raizc.addEventListener("mouseout", function(){
raizc.setAttribute("style","transform:scale(1,1)")
})

/*
document.getElementById('display').style.display ='inherit'; // muestra
document.getElementById('display').style.display ='none'; // oculta
*/
